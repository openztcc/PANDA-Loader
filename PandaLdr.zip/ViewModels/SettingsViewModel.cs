﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace PandaLdr.ViewModels
{
    internal class SettingsViewModel : ViewModelBase
    {
        public SettingsViewModel() { }
    }
}
