﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace PandaLdr.ViewModels
{
    public class ViewModelBase : ObservableObject
    {
    }
}
